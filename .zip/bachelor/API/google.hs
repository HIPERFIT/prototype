import Network.Http.Client

month_name "01" = "Jan"
month_name "02" = "Feb"
month_name "03" = "Mar"
month_name "04" = "Apr"
month_name "05" = "May"
month_name "06" = "Jun"
month_name "07" = "Jul"
month_name "08" = "Aug"
month_name "09" = "Sep"
month_name "10" = "Oct"
month_name "11" = "Nov"
month_name "12" = "Dec"
month_name month = "error"

format_date date =
    month_name([date !! 5 , date !! 6]) ++ "+" ++
    date !! 8 : date !! 9 : "+" ++
    date !! 0 : date !! 1 : date !! 2 : date !! 3 : ""

--Format of date: yyyy-mm-dd
google_finance_gen_link id start_date end_date =
    "http://www.google.com/finance/historical?" ++
    "q=" ++ id                                  ++
    "&startdate=" ++ format_date start_date     ++
    "&enddate=" ++ format_date end_date         ++
    "&output=csv"
