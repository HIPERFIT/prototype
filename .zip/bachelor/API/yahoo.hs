--Format of date: yyyy-mm-dd
yahoo_finance_gen_link id start_date end_date =
    "real-chart.finance.yahoo.com/table.csv?"   ++
    "s=" ++ id                                  ++
    "&a=" ++ [start_date !! 5, start_date !! 6] ++
    "&b=" ++ [start_date !! 8, start_date !! 9] ++
    "&c=" ++ [start_date !! 0, start_date !! 1,
              start_date !! 2, start_date !! 3] ++
    "&d=" ++ [end_date !! 5, end_date !! 6]     ++
    "&e=" ++ [end_date !! 8, end_date !! 9]     ++
    "&f=" ++ [end_date !! 0, end_date !! 1,
              end_date !! 2, end_date !! 3]     ++
    "&g=d"                                      ++ --time interval

    "&ignore=.csv"
