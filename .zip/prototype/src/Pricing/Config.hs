module Config where

genDataPath = "./generated/"
genCodePath = "./generated/"

genericPricingPath = "./finpar/GenericPricing/"
pricingEnginePath = genericPricingPath ++ "CppOpenCL/"
pricerCodePath = pricingEnginePath ++ "ContractDefs/"
pricerDataPath = genericPricingPath ++ "Data/Medium/"
