{-# LANGUAGE GADTs, DeriveGeneric, FlexibleInstances, FlexibleContexts #-}
{-# LANGUAGE OverloadedStrings, StandaloneDeriving #-}
module Service where

import View
import Pricing (runPricing)
import DataProviders.Data
import DataProviders.Common
import CodeGen.DataGen hiding (startDate)
import Contract.Expr
import Contract.Type
import Contract.Environment
import Contract.Transform
import Contract.Analysis
import TypeClass
import Data
import PersistentData
import DB
import Serialization
import Utils
import CodeGen.Utils
import Auth
import Stocks.FetchStocks

import Web.Scotty hiding (body, params)
import Web.Scotty.Internal.Types hiding (Env)
import Network.Wai.Middleware.Static (staticPolicy, addBase)
import CSS
import Data.Aeson (object, (.=), FromJSON(..), decode, eitherDecode, Value (..), encode, ToJSON (..))
import Control.Monad.Trans
import Control.Monad (when)
import qualified Data.Map as M
import qualified Data.ByteString.Lazy.Char8 as BL
import qualified Data.ByteString as W
import Data.Word
import GHC.Generics
import Data.Data
import qualified Data.Text.Lazy as TL
import qualified Data.Text as T
import qualified Database.Persist as P
import Database.Persist.Sql (toSqlKey, fromSqlKey)
import Data.Time (Day, diffDays, addDays)
import Data.Text (Text)
import Data.Maybe
import Data.Time.Clock
import Data.Time.Calendar

instance FromJSON CommonContractData
instance FromJSON PricingForm
instance FromJSON DataForm
instance FromJSON CorrForm
instance FromJSON PercentField
instance ToJSON PercentField

defaultService allContracts dataProvider = do
    get "/" $ basicAuth $ homeView allContracts
    get (capture $ contractsBaseUrl ++ ":type") $ do
                       ty <- param "type"
                       code <- liftIO $ readInstrument $ capFirst ty
                       contractView allContracts (toMap allContracts M.! ty) code
    post "/pricer/" $ basicAuth $ do
      pricingForm <- (jsonParam "conf") :: ActionM PricingForm
      pItems <- liftIO ((runDb $ P.selectList [] []) :: IO [P.Entity PFItem])
      res <- liftIO $ mapM (maybeValuate pricingForm dataProvider) $ map P.entityVal pItems
      json $ object [ "prices" .= res
                    , "total"  .= (sum $ map (fromMaybe 0) res) ]
    get "/portfolio/" $ basicAuth $ do
      pItems <- liftIO ((runDb $ P.selectList [] []) :: IO [P.Entity PFItem])
      currDate <- liftIO getCurrentTime
      portfolioView (map (withHorizon . fromEntity) pItems) $
                    [("currentDate", Just $ show $ utctDay currDate), ("interestRate", Just "2"), ("iterations", Just "10000")]
    delete "/portfolio/:id" $ basicAuth $ do
      pfiId <- param "id"
      let key = toSqlKey (fromIntegral ((read pfiId) :: Integer)) :: P.Key PFItem
      liftIO $ runDb $ P.delete key
      text "OK"
    get "/marketData/underlyings/" $ basicAuth $ do
      availUnd <- liftIO (storedUnderlyings dataProvider)
      json availUnd
    get "/marketData/view/" $ basicAuth $ do 
      quotes <- liftIO $ storedQuotes dataProvider
      corrs  <- liftIO $ storedCorrs dataProvider
      marketDataView quotes corrs
    post "/marketData/quotes/" $ basicAuth $ do
      form <- jsonData :: ActionM DataForm
      let md = DbQuotes (fUnderlying form) (fDate form) (fVal form) (toSqlKey (fromIntegral defaultUserId))
      liftIO $ runDb $ P.insert_ md
      json $ object ["msg" .= ("Data added successfully" :: String)]
    delete "/marketData/quotes/" $ basicAuth $ do
      key <- jsonData :: ActionM (Text, Day)
      liftIO $ runDb $ P.deleteBy $ (uncurry QuoteEntry) key
      text "OK"
    delete "/marketData/corrs/" $ basicAuth $ do
      (und1, und2, d) <- jsonData :: ActionM (Text, Text, Day)
      liftIO $ runDb $ P.deleteBy $ CorrEntry und1 und2 d
      text "OK"
    post "/marketData/corrs/" $ basicAuth $ do
      form <- jsonData :: ActionM CorrForm
      let corr = DbCorr (corrUnd1 form) (corrUnd2 form) (corrDate form) (corrVal form) (toSqlKey (fromIntegral defaultUserId))
      liftIO $ runDb $ P.insert_ corr
      json $ object ["msg" .= ("Data added successfully" :: String)]
    get "/modelData/" $ basicAuth $ do
      md <- liftIO $ storedModelData dataProvider
      modelDataView md
    post   "/modelData/" $ basicAuth $ do
      form <- jsonData :: ActionM DataForm
      let md = DbModelData (fUnderlying form) (fDate form) (fVal form) (toSqlKey (fromIntegral defaultUserId))
      liftIO $ runDb $ P.insert_ md
      json $ object ["msg" .= ("Data added successfully" :: String)]
    delete "/modelData/" $ basicAuth $ do
      key <- jsonData :: ActionM (Text, Day)
      liftIO $ runDb $ P.deleteBy $ (uncurry MDEntry) key
      text "OK"
    get   "/marketData/stocks/:id" $ basicAuth $ do
      stock_id <- param "id"
      startdate <- param "startdate"
      enddate <- param "enddate"
      stockData <- liftIO $ getStocks stock_id startdate enddate "Yahoo"
      json stockData
    middleware $ staticPolicy (addBase "src/Web/static")

api contractType inputData mkContr = 
    post (literal ("/api/" ++ contractType)) $
         do
           commonData <- (jsonParam "common" :: ActionM CommonContractData)
           contractData <- inputData 
           pItems <- liftIO $ runDb $ P.insert $ toPFItem commonData contractData $ mkContr (startDate commonData) contractData
           json $ object ["msg" .= ("Contract added successfully" :: String)]

toMap = M.fromList . map (\c -> (url c, c))

-- Parse contents of parameter p as a JSON object and return it. Raises an exception if parse is unsuccessful.
jsonParam p = do
  b <- param p
  either (\e -> raise $ stringError $ "jsonData - no parse: " ++ e ++ ". Data was:" ++ BL.unpack b) return $ eitherDecode b

jsonContract :: (FromJSON a) => ActionM a
jsonContract = jsonParam ("contractData" :: TL.Text)

toPFItem commonData cInput cs = PFItem { pFItemStartDate = startDate commonData
                                       , pFItemContractType = TL.toStrict $ TL.pack $ show $ typeOf cInput
                                       , pFItemNominal = nominal commonData
                                       , pFItemContractSpec = T.pack $ show cs
                                       , pFItemPortfolioId = toSqlKey $ fromIntegral defaultPortfolioId }

-- TODO: Refactoring needed. Possibly, merge with mkData
makeInput :: MContract -> PricingForm -> DataProvider -> IO ((DiscModel, [Model], MarketData), MContract)
makeInput mContr@(sDate, contr) pricingForm dataProvider = do
  (modelData, marketData) <- mkData mContr pricingForm dataProvider
  return ( (ConstDisc $ fromPercentField $ interestRate pricingForm
           , modelData
           , marketData) 
         , mContr)
    where
      currDate = fromMaybe (contrDate2Day sDate) $ currentDate pricingForm 
      dt = fromIntegral $ diffDays currDate $ contrDate2Day sDate
      cMeta = extractMeta mContr
      allDays = map contrDate2Day (allDates cMeta)

mkData mContr@(sDate, contr) pricingForm dataProvider = do
  rawModelData <- mapM (getRawModelData allDays) unds
  rawQuotes <- mapM (getRawQuotes $ (contrDate2Day sDate) : allDays) unds
  rawCorrs <- getRawCorrs currDate unds
  return ( map toBS $ zip unds $ rawModelData
         , toMarketData $ (concat rawQuotes, rawCorrs))
    where
      currDate = fromMaybe (contrDate2Day sDate) $ currentDate pricingForm 
      toBS (und, md) = bsRiskFreeRate und (map convertDate md) (fromPercentField $ interestRate pricingForm) sDate eDate
      cMeta = extractMeta mContr
      eDate = endDate cMeta
      unds  = underlyings cMeta
      allDays = map contrDate2Day (allDates cMeta)
      getRawModelData = provideModelData dataProvider
      getRawQuotes = provideQuotes dataProvider
      getRawCorrs = provideCorrs dataProvider
      convertDate (u, d, v) = (u, day2ContrDate d, v)

makeEnv quotes = foldr (.) id $ map f quotes
    where
      f (und, d, q) = addFixing (und, day2ContrDate d, q)

maybeValuate :: PricingForm -> DataProvider -> PFItem -> IO (Maybe Double)
maybeValuate pricingForm dataProvider portfItem = if (dt >= 0) then
                                                      do v <- valuate pricingForm dataProvider portfItem
                                                         return $ Just v
                                                  else return Nothing
    where
      currDate = fromMaybe (pFItemStartDate portfItem) $ currentDate pricingForm
      dt = fromIntegral $ diffDays currDate $ pFItemStartDate portfItem

valuate pricingForm dataProvider portfItem = do
  quotesBefore <- mapM (getRawQuotes $ sDate : filter (<= currDate) allDays) unds
  let env = (makeEnv (concat quotesBefore)) $ emptyFrom $ day2ContrDate sDate
      simplContr = advance dt $ simplify env mContr
  (inp, contr) <- makeInput simplContr pricingForm dataProvider
  let iter = DataConf { monteCarloIter =  (iterations pricingForm) }
      nominal_ = (fromIntegral (pFItemNominal portfItem))
  [val] <- runPricing iter [inp] contr
  return $  nominal_ * val
  where
    currDate = fromMaybe sDate $ currentDate pricingForm 
    dt = fromIntegral $ diffDays currDate sDate
    sDate = pFItemStartDate portfItem
    mZero = (day2ContrDate sDate, zero)
    mContr = (day2ContrDate sDate, read $ T.unpack $ pFItemContractSpec portfItem)
    cMeta = extractMeta mContr
    allDays = map contrDate2Day (allDates cMeta)
    unds  = underlyings cMeta      
    getRawQuotes = provideQuotes dataProvider

fromEntity p = (show $ fromSqlKey $ P.entityKey p, P.entityVal p)

withHorizon (key, enity) = (key, enity, addDays days $ pFItemStartDate enity) 
    where
      days = fromIntegral $ horizon $ read $ T.unpack $ pFItemContractSpec enity

createDefaultUser = createIfNotExist (defaultUserId, User "hiperfit" "123")
  
createDefaultPortfolio = createIfNotExist (defaultPortfolioId, Portfolio "HIPERFIT" (toSqlKey $ fromIntegral defaultUserId))

createIfNotExist (entId, ent) = do
    let key = toSqlKey $ fromIntegral entId
    ent_ <- runDb $ P.get key
    let exist = case ent_ of
                   Just _ -> False
                   Nothing -> True
    when exist $ runDb $ P.insertKey key ent

readInstrument name = do
  allCode <- readFile ("src/Web/Instrument/" ++ name ++ ".hs")
  let [_,res] = T.splitOn "{-@CODE@-}" $ T.pack allCode
  return res

authUser u p | u == "hiperfit" && p == "123" = Authorized
             | otherwise = Unauthorized
